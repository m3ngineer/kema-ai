import json
import logging
import sys
from sqlalchemy import create_engine
import pymysql
import psycopg2

import conf

def connect_to_rds(return_engine=False):
    ''' Connects to RDS and returns connection '''
    engine = create_engine(
            "postgresql://{}:{}@{}/{}".format(
                conf.RDS_user,
                conf.RDS_password,
                conf.RDS_host,
                conf.RDS_db_name,
                )
            )
    if return_engine:
        return engine

    conn = engine.connect()
    return conn

# logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# connect_to_rds()
# conn = pymysql.connect(conf.RDS_host, user=conf.RDS_user, passwd=conf.RDS_password, db=conf.RDS_db_name, connect_timeout=5)
psycopg2.connect(database=conf.RDS_db_name,
                    host=conf.RDS_host,
                    user=conf.RDS_user,
                    password=conf.RDS_password)

try:
    # connect_to_rds()
    conn = pymysql.connect(conf.RDS_host, user=conf.RDS_user, passwd=conf.RDS_password, db=conf.RDS_db_name, connect_timeout=5)

except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")

def lambda_handler(event, context):
    # TODO implement

    # data = {
    #     json.dumps(event)
    # }


    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        'data': event
    }
