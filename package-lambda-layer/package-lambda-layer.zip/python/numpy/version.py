
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.17.0'
version = '1.17.0'
full_version = '1.17.0'
git_revision = 'd9b1e32cb8ef90d6b4a47853241db2a28146a57d'
release = True

if not release:
    version = full_version
